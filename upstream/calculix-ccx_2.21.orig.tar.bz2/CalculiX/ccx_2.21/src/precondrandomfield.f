!     
!     CalculiX - A 3-dimensional finite element program
!     Copyright (C) 1998-2023 Guido Dhondt
!     
!     This program is free software; you can redistribute it and/or
!     modify it under the terms of the GNU General Public License as
!     published by the Free Software Foundation(version 2);
!     
!     
!     This program is distributed in the hope that it will be useful,
!     but WITHOUT ANY WARRANTY; without even the implied warranty of 
!     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
!     GNU General Public License for more details.
!     
!     You should have received a copy of the GNU General Public License
!     along with this program; if not, write to the Free Software
!     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
!     
      subroutine precondrandomfield(auc,jqc,irowc,rhs,idesvar)       
!     
!     Assembly of the right hand side
!     
      implicit none
!     
      integer i,idesvar,jqc(*),irowc(*),irow
!     
      real*8 auc(*),rhs(*)
!     
!     assembly of right hand side
!     
      do i=jqc(idesvar),jqc(idesvar+1)-1
        irow=irowc(i)
        rhs(irow)=auc(i)
      enddo
!     
      return        
      end

